// =============================================================================
// jingle_player.sv
// Plays a short 5-tone chime (F#-C#-F#-C#-G#) in the style of the
// well-known "Intel Inside" audio sonic logo, using a small wavetable
// synthesizer (DDS phase accumulator + harmonic waveform ROM + percussive
// attack/decay envelope) driving an 8-bit PWM DAC, so the timbre sounds
// closer to a struck/plucked piano note than a plain square wave.
// Output feeds PMOD-AUDIO v1.2's onboard RC filter + PAM8403 amplifier
// (IL input, board Port1). Loops with a 2 s gap between repeats.
//
// All ROM content is implemented as synthesis-safe `case` statements
// (no `initial` blocks), matching project convention.
// =============================================================================
module jingle_player #(
    parameter int CLK_HZ    = 50_000_000,
    parameter int AUDIO_DIV = 1042          // audio sample tick every AUDIO_DIV clk cycles (~48kHz)
) (
    input  logic clk,
    input  logic rst,
    output logic audio
);

    // -------------------------------------------------------------------
    // Note / duration step table (5 tones + trailing rest/gap, then loop)
    //
    //  step | note | freq(Hz) | phase_inc (Q16, Fs~=48kHz) | dur(ms)
    //   0   | F#4  |  369.99  |  505                        |  200
    //   1   | C#4  |  277.18  |  379                        |  200
    //   2   | F#4  |  369.99  |  505                        |  200
    //   3   | C#4  |  277.18  |  379                        |  200
    //   4   | G#4  |  415.30  |  567                        |  600
    //   5   | (rest/gap)  --  |    0                        | 2000
    // -------------------------------------------------------------------
    localparam int         NUM_STEPS = 6;
    localparam logic [2:0] REST_STEP = 3'd5;

    logic [2:0]  step;
    logic [15:0] phase_inc;
    logic [26:0] duration_cyc;
    logic        note_active;

    assign note_active = (step != REST_STEP);

    always_comb begin
        unique case (step)
            3'd0: begin phase_inc = 16'd505; duration_cyc = 27'd10_000_000; end // F#4, 200ms
            3'd1: begin phase_inc = 16'd379; duration_cyc = 27'd10_000_000; end // C#4, 200ms
            3'd2: begin phase_inc = 16'd505; duration_cyc = 27'd10_000_000; end // F#4, 200ms
            3'd3: begin phase_inc = 16'd379; duration_cyc = 27'd10_000_000; end // C#4, 200ms
            3'd4: begin phase_inc = 16'd567; duration_cyc = 27'd30_000_000; end // G#4, 600ms
            default: begin phase_inc = 16'd0; duration_cyc = 27'd100_000_000; end // 2000ms rest
        endcase
    end

    // ---------------------------------------------------------------
    // Step/duration sequencer
    // ---------------------------------------------------------------
    logic [26:0] dur_cnt;
    logic        step_done;

    assign step_done = (dur_cnt == duration_cyc - 27'd1);

    always_ff @(posedge clk) begin
        if (rst) begin
            dur_cnt <= '0;
            step    <= '0;
        end else if (step_done) begin
            dur_cnt <= '0;
            step    <= (step == NUM_STEPS - 1) ? 3'd0 : step + 3'd1;
        end else begin
            dur_cnt <= dur_cnt + 27'd1;
        end
    end

    // ---------------------------------------------------------------
    // Audio sample-rate tick (~48kHz strobe, free running)
    // ---------------------------------------------------------------
    logic [10:0] smp_cnt;
    logic        smp_en;

    assign smp_en = (smp_cnt == AUDIO_DIV - 1);

    always_ff @(posedge clk) begin
        if (rst)          smp_cnt <= '0;
        else if (smp_en)  smp_cnt <= '0;
        else              smp_cnt <= smp_cnt + 11'd1;
    end

    // ---------------------------------------------------------------
    // DDS phase accumulator (resets to 0 on each note-on for a clean attack)
    // ---------------------------------------------------------------
    logic [15:0] phase;

    always_ff @(posedge clk) begin
        if (rst) begin
            phase <= '0;
        end else if (step_done) begin
            phase <= '0;                    // new note starts at phase 0
        end else if (smp_en && note_active) begin
            phase <= phase + phase_inc;
        end
    end

    // ---------------------------------------------------------------
    // Percussive attack/decay envelope (fast linear attack, exponential
    // "leaky" decay) -- gives the wavetable output its piano/struck-note
    // character instead of a constant sustained level.
    // ---------------------------------------------------------------
    localparam logic       ENV_ATTACK  = 1'b0;
    localparam logic       ENV_DECAY   = 1'b1;
    localparam logic [7:0] ATTACK_STEP = 8'd8;   // envelope units added per sample (~0.7ms to full scale)
    localparam int         DECAY_TICK  = 40;     // samples between each decay update (~0.8ms @48kHz)
    localparam int         DECAY_SHIFT = 6;       // decay rate: env -= env >> DECAY_SHIFT

    logic       env_state;
    logic [7:0] env;
    logic [5:0] decay_cnt;

    always_ff @(posedge clk) begin
        if (rst) begin
            env       <= 8'd0;
            env_state <= ENV_ATTACK;
            decay_cnt <= '0;
        end else if (step_done) begin
            env       <= 8'd0;
            env_state <= ENV_ATTACK;
            decay_cnt <= '0;
        end else if (smp_en) begin
            if (!note_active) begin
                env <= 8'd0;                                  // silent during rest step
            end else if (env_state == ENV_ATTACK) begin
                if (env >= 8'd255 - ATTACK_STEP) begin
                    env       <= 8'd255;
                    env_state <= ENV_DECAY;
                end else begin
                    env <= env + ATTACK_STEP;
                end
            end else begin // ENV_DECAY
                if (decay_cnt == DECAY_TICK - 1) begin
                    decay_cnt <= '0;
                    env       <= env - (env >> DECAY_SHIFT);
                end else begin
                    decay_cnt <= decay_cnt + 6'd1;
                end
            end
        end
    end

    // ---------------------------------------------------------------
    // Piano-ish single-cycle waveform ROM (256 entries, signed 8-bit),
    // built from a decaying harmonic series (1st..8th harmonic) typical
    // of a struck string's spectral envelope.
    // ---------------------------------------------------------------
    function automatic logic signed [7:0] wave_rom(input logic [7:0] idx);
        case (idx)
            8'd0: wave_rom = 8'sd0;
            8'd1: wave_rom = 8'sd10;
            8'd2: wave_rom = 8'sd21;
            8'd3: wave_rom = 8'sd31;
            8'd4: wave_rom = 8'sd41;
            8'd5: wave_rom = 8'sd51;
            8'd6: wave_rom = 8'sd60;
            8'd7: wave_rom = 8'sd69;
            8'd8: wave_rom = 8'sd77;
            8'd9: wave_rom = 8'sd85;
            8'd10: wave_rom = 8'sd92;
            8'd11: wave_rom = 8'sd98;
            8'd12: wave_rom = 8'sd104;
            8'd13: wave_rom = 8'sd109;
            8'd14: wave_rom = 8'sd113;
            8'd15: wave_rom = 8'sd117;
            8'd16: wave_rom = 8'sd120;
            8'd17: wave_rom = 8'sd122;
            8'd18: wave_rom = 8'sd124;
            8'd19: wave_rom = 8'sd126;
            8'd20: wave_rom = 8'sd126;
            8'd21: wave_rom = 8'sd127;
            8'd22: wave_rom = 8'sd127;
            8'd23: wave_rom = 8'sd127;
            8'd24: wave_rom = 8'sd126;
            8'd25: wave_rom = 8'sd125;
            8'd26: wave_rom = 8'sd124;
            8'd27: wave_rom = 8'sd123;
            8'd28: wave_rom = 8'sd122;
            8'd29: wave_rom = 8'sd121;
            8'd30: wave_rom = 8'sd119;
            8'd31: wave_rom = 8'sd118;
            8'd32: wave_rom = 8'sd116;
            8'd33: wave_rom = 8'sd115;
            8'd34: wave_rom = 8'sd113;
            8'd35: wave_rom = 8'sd112;
            8'd36: wave_rom = 8'sd110;
            8'd37: wave_rom = 8'sd109;
            8'd38: wave_rom = 8'sd107;
            8'd39: wave_rom = 8'sd106;
            8'd40: wave_rom = 8'sd104;
            8'd41: wave_rom = 8'sd103;
            8'd42: wave_rom = 8'sd101;
            8'd43: wave_rom = 8'sd100;
            8'd44: wave_rom = 8'sd98;
            8'd45: wave_rom = 8'sd96;
            8'd46: wave_rom = 8'sd95;
            8'd47: wave_rom = 8'sd93;
            8'd48: wave_rom = 8'sd91;
            8'd49: wave_rom = 8'sd90;
            8'd50: wave_rom = 8'sd88;
            8'd51: wave_rom = 8'sd86;
            8'd52: wave_rom = 8'sd84;
            8'd53: wave_rom = 8'sd83;
            8'd54: wave_rom = 8'sd81;
            8'd55: wave_rom = 8'sd80;
            8'd56: wave_rom = 8'sd78;
            8'd57: wave_rom = 8'sd76;
            8'd58: wave_rom = 8'sd75;
            8'd59: wave_rom = 8'sd74;
            8'd60: wave_rom = 8'sd72;
            8'd61: wave_rom = 8'sd71;
            8'd62: wave_rom = 8'sd70;
            8'd63: wave_rom = 8'sd69;
            8'd64: wave_rom = 8'sd67;
            8'd65: wave_rom = 8'sd66;
            8'd66: wave_rom = 8'sd65;
            8'd67: wave_rom = 8'sd64;
            8'd68: wave_rom = 8'sd63;
            8'd69: wave_rom = 8'sd62;
            8'd70: wave_rom = 8'sd61;
            8'd71: wave_rom = 8'sd60;
            8'd72: wave_rom = 8'sd59;
            8'd73: wave_rom = 8'sd58;
            8'd74: wave_rom = 8'sd56;
            8'd75: wave_rom = 8'sd55;
            8'd76: wave_rom = 8'sd54;
            8'd77: wave_rom = 8'sd53;
            8'd78: wave_rom = 8'sd51;
            8'd79: wave_rom = 8'sd50;
            8'd80: wave_rom = 8'sd49;
            8'd81: wave_rom = 8'sd47;
            8'd82: wave_rom = 8'sd46;
            8'd83: wave_rom = 8'sd44;
            8'd84: wave_rom = 8'sd43;
            8'd85: wave_rom = 8'sd41;
            8'd86: wave_rom = 8'sd40;
            8'd87: wave_rom = 8'sd39;
            8'd88: wave_rom = 8'sd37;
            8'd89: wave_rom = 8'sd36;
            8'd90: wave_rom = 8'sd35;
            8'd91: wave_rom = 8'sd34;
            8'd92: wave_rom = 8'sd33;
            8'd93: wave_rom = 8'sd32;
            8'd94: wave_rom = 8'sd31;
            8'd95: wave_rom = 8'sd30;
            8'd96: wave_rom = 8'sd29;
            8'd97: wave_rom = 8'sd28;
            8'd98: wave_rom = 8'sd27;
            8'd99: wave_rom = 8'sd26;
            8'd100: wave_rom = 8'sd25;
            8'd101: wave_rom = 8'sd24;
            8'd102: wave_rom = 8'sd23;
            8'd103: wave_rom = 8'sd23;
            8'd104: wave_rom = 8'sd22;
            8'd105: wave_rom = 8'sd21;
            8'd106: wave_rom = 8'sd20;
            8'd107: wave_rom = 8'sd19;
            8'd108: wave_rom = 8'sd18;
            8'd109: wave_rom = 8'sd17;
            8'd110: wave_rom = 8'sd16;
            8'd111: wave_rom = 8'sd15;
            8'd112: wave_rom = 8'sd14;
            8'd113: wave_rom = 8'sd13;
            8'd114: wave_rom = 8'sd12;
            8'd115: wave_rom = 8'sd11;
            8'd116: wave_rom = 8'sd10;
            8'd117: wave_rom = 8'sd9;
            8'd118: wave_rom = 8'sd8;
            8'd119: wave_rom = 8'sd7;
            8'd120: wave_rom = 8'sd6;
            8'd121: wave_rom = 8'sd5;
            8'd122: wave_rom = 8'sd4;
            8'd123: wave_rom = 8'sd4;
            8'd124: wave_rom = 8'sd3;
            8'd125: wave_rom = 8'sd2;
            8'd126: wave_rom = 8'sd1;
            8'd127: wave_rom = 8'sd1;
            8'd128: wave_rom = 8'sd0;
            8'd129: wave_rom = 8'sd-1;
            8'd130: wave_rom = 8'sd-1;
            8'd131: wave_rom = 8'sd-2;
            8'd132: wave_rom = 8'sd-3;
            8'd133: wave_rom = 8'sd-4;
            8'd134: wave_rom = 8'sd-4;
            8'd135: wave_rom = 8'sd-5;
            8'd136: wave_rom = 8'sd-6;
            8'd137: wave_rom = 8'sd-7;
            8'd138: wave_rom = 8'sd-8;
            8'd139: wave_rom = 8'sd-9;
            8'd140: wave_rom = 8'sd-10;
            8'd141: wave_rom = 8'sd-11;
            8'd142: wave_rom = 8'sd-12;
            8'd143: wave_rom = 8'sd-13;
            8'd144: wave_rom = 8'sd-14;
            8'd145: wave_rom = 8'sd-15;
            8'd146: wave_rom = 8'sd-16;
            8'd147: wave_rom = 8'sd-17;
            8'd148: wave_rom = 8'sd-18;
            8'd149: wave_rom = 8'sd-19;
            8'd150: wave_rom = 8'sd-20;
            8'd151: wave_rom = 8'sd-21;
            8'd152: wave_rom = 8'sd-22;
            8'd153: wave_rom = 8'sd-23;
            8'd154: wave_rom = 8'sd-23;
            8'd155: wave_rom = 8'sd-24;
            8'd156: wave_rom = 8'sd-25;
            8'd157: wave_rom = 8'sd-26;
            8'd158: wave_rom = 8'sd-27;
            8'd159: wave_rom = 8'sd-28;
            8'd160: wave_rom = 8'sd-29;
            8'd161: wave_rom = 8'sd-30;
            8'd162: wave_rom = 8'sd-31;
            8'd163: wave_rom = 8'sd-32;
            8'd164: wave_rom = 8'sd-33;
            8'd165: wave_rom = 8'sd-34;
            8'd166: wave_rom = 8'sd-35;
            8'd167: wave_rom = 8'sd-36;
            8'd168: wave_rom = 8'sd-37;
            8'd169: wave_rom = 8'sd-39;
            8'd170: wave_rom = 8'sd-40;
            8'd171: wave_rom = 8'sd-41;
            8'd172: wave_rom = 8'sd-43;
            8'd173: wave_rom = 8'sd-44;
            8'd174: wave_rom = 8'sd-46;
            8'd175: wave_rom = 8'sd-47;
            8'd176: wave_rom = 8'sd-49;
            8'd177: wave_rom = 8'sd-50;
            8'd178: wave_rom = 8'sd-51;
            8'd179: wave_rom = 8'sd-53;
            8'd180: wave_rom = 8'sd-54;
            8'd181: wave_rom = 8'sd-55;
            8'd182: wave_rom = 8'sd-56;
            8'd183: wave_rom = 8'sd-58;
            8'd184: wave_rom = 8'sd-59;
            8'd185: wave_rom = 8'sd-60;
            8'd186: wave_rom = 8'sd-61;
            8'd187: wave_rom = 8'sd-62;
            8'd188: wave_rom = 8'sd-63;
            8'd189: wave_rom = 8'sd-64;
            8'd190: wave_rom = 8'sd-65;
            8'd191: wave_rom = 8'sd-66;
            8'd192: wave_rom = 8'sd-67;
            8'd193: wave_rom = 8'sd-69;
            8'd194: wave_rom = 8'sd-70;
            8'd195: wave_rom = 8'sd-71;
            8'd196: wave_rom = 8'sd-72;
            8'd197: wave_rom = 8'sd-74;
            8'd198: wave_rom = 8'sd-75;
            8'd199: wave_rom = 8'sd-76;
            8'd200: wave_rom = 8'sd-78;
            8'd201: wave_rom = 8'sd-80;
            8'd202: wave_rom = 8'sd-81;
            8'd203: wave_rom = 8'sd-83;
            8'd204: wave_rom = 8'sd-84;
            8'd205: wave_rom = 8'sd-86;
            8'd206: wave_rom = 8'sd-88;
            8'd207: wave_rom = 8'sd-90;
            8'd208: wave_rom = 8'sd-91;
            8'd209: wave_rom = 8'sd-93;
            8'd210: wave_rom = 8'sd-95;
            8'd211: wave_rom = 8'sd-96;
            8'd212: wave_rom = 8'sd-98;
            8'd213: wave_rom = 8'sd-100;
            8'd214: wave_rom = 8'sd-101;
            8'd215: wave_rom = 8'sd-103;
            8'd216: wave_rom = 8'sd-104;
            8'd217: wave_rom = 8'sd-106;
            8'd218: wave_rom = 8'sd-107;
            8'd219: wave_rom = 8'sd-109;
            8'd220: wave_rom = 8'sd-110;
            8'd221: wave_rom = 8'sd-112;
            8'd222: wave_rom = 8'sd-113;
            8'd223: wave_rom = 8'sd-115;
            8'd224: wave_rom = 8'sd-116;
            8'd225: wave_rom = 8'sd-118;
            8'd226: wave_rom = 8'sd-119;
            8'd227: wave_rom = 8'sd-121;
            8'd228: wave_rom = 8'sd-122;
            8'd229: wave_rom = 8'sd-123;
            8'd230: wave_rom = 8'sd-124;
            8'd231: wave_rom = 8'sd-125;
            8'd232: wave_rom = 8'sd-126;
            8'd233: wave_rom = 8'sd-127;
            8'd234: wave_rom = 8'sd-127;
            8'd235: wave_rom = 8'sd-127;
            8'd236: wave_rom = 8'sd-126;
            8'd237: wave_rom = 8'sd-126;
            8'd238: wave_rom = 8'sd-124;
            8'd239: wave_rom = 8'sd-122;
            8'd240: wave_rom = 8'sd-120;
            8'd241: wave_rom = 8'sd-117;
            8'd242: wave_rom = 8'sd-113;
            8'd243: wave_rom = 8'sd-109;
            8'd244: wave_rom = 8'sd-104;
            8'd245: wave_rom = 8'sd-98;
            8'd246: wave_rom = 8'sd-92;
            8'd247: wave_rom = 8'sd-85;
            8'd248: wave_rom = 8'sd-77;
            8'd249: wave_rom = 8'sd-69;
            8'd250: wave_rom = 8'sd-60;
            8'd251: wave_rom = 8'sd-51;
            8'd252: wave_rom = 8'sd-41;
            8'd253: wave_rom = 8'sd-31;
            8'd254: wave_rom = 8'sd-21;
            8'd255: wave_rom = 8'sd-10;
        endcase
    endfunction

    logic signed [7:0] wave_sample;
    assign wave_sample = wave_rom(phase[15:8]);

    // ---------------------------------------------------------------
    // wave_sample (signed) x env (unsigned volume) -> 8-bit PWM duty
    // ---------------------------------------------------------------
    logic signed [16:0] product;
    logic signed [9:0]  duty_sum;
    logic [7:0]          pwm_duty;

    assign product  = wave_sample * $signed({1'b0, env});
    assign duty_sum = 10'sd128 + (product >>> 8);
    assign pwm_duty = duty_sum[7:0];

    // ---------------------------------------------------------------
    // 8-bit PWM DAC, free-running at CLK_HZ/256 (~195kHz carrier)
    // ---------------------------------------------------------------
    logic [7:0] pwm_cnt;

    always_ff @(posedge clk) begin
        if (rst) pwm_cnt <= '0;
        else     pwm_cnt <= pwm_cnt + 8'd1;
    end

    assign audio = (pwm_cnt < pwm_duty);

endmodule
